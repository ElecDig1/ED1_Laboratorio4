transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vlog -vlog01compat -work work +incdir+D:/Proyectos/Quartus/pwm {D:/Proyectos/Quartus/pwm/top_pwm_generator.v}

